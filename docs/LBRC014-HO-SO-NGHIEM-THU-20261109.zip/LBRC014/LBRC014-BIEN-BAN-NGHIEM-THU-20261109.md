# BIÊN BẢN TỔNG HỢP BẰNG CHỨNG VÀ BỔ SUNG NGHIỆM THU — LBRC014

**Tính năng:** Chỉ đường tới điểm bán — App Saleman  
**Ngày lập:** 09/11/2026 · **Bản lập đầu**  
**Trạng thái hồ sơ:** Chờ Quân, Phương bổ sung bằng chứng và xác nhận.  
**Người tổng hợp:** Trợ lý kỹ thuật, theo yêu cầu Chairman. Đây là hồ sơ tổng hợp từ nguồn, chưa có xác nhận mới của Quân, Phương hoặc người review.

## 1. Kết luận tại thời điểm lập

Bảng việc đang ghi **“Hoàn thành”**, kèm lời báo **“PhươngHV 7/11: nghiệm thu đạt, đóng.”** Mã chức năng đã được xác minh tại đúng commit và có trong nhánh main quan sát ngày 09/11. Hồ sơ đã thu thập còn thiếu mối nối từ lời nghiệm thu tới bản cài, kết quả test/UAT và xác nhận review. Nguồn: `lbrc014-20261109/workbook-current.json:1`, `lbrc014-20261109/commit.json:1`, `lbrc014-20261109/compare.json:1`.

**Biên bản giữ nguyên trạng thái nguồn.** Việc cần làm là hoàn thiện hồ sơ chứng minh bản nào đã được nghiệm thu. Nhận định về khoảng thiếu chỉ áp dụng bộ nguồn đã đối soát sáng 09/11; bằng chứng ở nơi khác có thể được bổ sung bằng liên kết gốc.

## 2. Định danh và phạm vi

| Trường | Ghi nhận |
|---|---|
| Mã việc | LBRC014 |
| Dòng nguồn | [Đầu việc Tech, A31:H31, STT 30](https://docs.google.com/spreadsheets/d/1Vr1ykZUtwm5Wvj1oAQRjpzMgleDa6Fhu-WiPv-L61Vc/edit#gid=1963754558&range=A31:H31) |
| Người phụ trách / phối hợp theo bảng | QuânTV / PhươngHV |
| Hạn theo bảng | 06/11/2026 |
| Trạng thái theo bảng | Hoàn thành |
| Ghi chú nguồn | LBRC014. Spec SPEC-chi-duong-diem-ban.md. Quân 6/11: chờ nghiệm thu. PhươngHV 7/11: nghiệm thu đạt, đóng. |
| Phạm vi tính năng | Nút Chỉ đường trên tab Hôm nay, danh sách Khách hàng và Chi tiết KH; chọn đích theo tọa độ/địa chỉ và xử lý thiếu dữ liệu hoặc lỗi mở bản đồ. |
| Phạm vi ngoài tính năng theo spec | Giữ hành vi màn bản đồ tuyến; không đổi backend/API và không thêm dependency. |

Nguồn: `lbrc014-20261109/workbook-current.json:1`, `lbrc014-20261109/spec-main.txt:11`. Phạm vi này chỉ dành cho LBRC014, không nghiệm thu các thay đổi khác cùng nằm trong bản app.

| Mốc mã nguồn đã xác minh | Giá trị |
|---|---|
| Commit chức năng | [`8d05141576bcd4db8e7ab9f1a6b7a0dd9bd360ab`](https://github.com/liberico-ai/btnet-saleman/commit/8d05141576bcd4db8e7ab9f1a6b7a0dd9bd360ab) |
| Commit thêm đặc tả | [`07348b551ca5101815c0d05bd9bff302832dad71`](https://github.com/liberico-ai/btnet-saleman/commit/07348b551ca5101815c0d05bd9bff302832dad71) |
| Main quan sát sáng 09/11 | `5b38598de8bca1b258be7ee4b7086a993810478a`; chứa commit chức năng trên |
| Phiên bản khai trong mã main | `1.0.27+29` — chưa xác định đây có phải bản được nghiệm thu ngày 07/11. Nguồn: `lbrc014-20261109/version-main.txt:19`. |
| **Bản cài thực tế được nghiệm thu / full SHA build** | **CHỜ QUÂN CUNG CẤP VÀ PHƯƠNG ĐỐI CHIẾU** |

Nguồn: `lbrc014-20261109/commit.json:1`, `lbrc014-20261109/spec-origin.json:1`, `lbrc014-20261109/compare.json:1`, `lbrc014-20261109/version-main.txt:19`.

## 3. Bằng chứng đã gom

| Mã | Bằng chứng trong hồ sơ | Kết quả đã xác minh | Giới hạn |
|---|---|---|---|
| E01 | [Dòng việc và metadata](lbrc014-20261109/workbook-current.json); [phạm vi cột/tab đã kiểm](lbrc014-20261109/workbook-extended-scope.json) | Có lời báo PhươngHV nghiệm thu và đóng ngày 07/11; dòng việc đọc lại sáng 09/11 giữ nội dung này. | Chưa gắn SHA/bản cài, kết quả từng ca hoặc biên bản nghiệm thu trong dòng nguồn. |
| E02 | [Commit chức năng](lbrc014-20261109/commit.json); [quan hệ với main](lbrc014-20261109/compare.json); [mã tại ba màn hình](lbrc014-20261109/current-code-excerpts.json) | Mã chức năng có thật, nằm trong main; ba màn hình còn dùng nút chỉ đường. | Chưa xác minh mã đó đang chạy trên thiết bị nghiệm thu. |
| E03 | [Đặc tả tại bản main đã đọc](lbrc014-20261109/spec-main.txt) | Đã mô tả phạm vi, hành vi, tình huống biên và yêu cầu UAT thiết bị. | Dòng 3 và mục 8 vẫn ghi Draft/chờ Arch Lead review; spec được viết sau code. |
| E04 | [Mã test](lbrc014-20261109/test-main.txt); [checks](lbrc014-20261109/checks.json); [Actions](lbrc014-20261109/actions.json); [statuses](lbrc014-20261109/statuses.json) | Có 9 ca unit/widget trong mã. GitHub trả 0 check runs, 0 workflow runs và 0 status contexts tại SHA chức năng. | Chưa có log chạy đạt gắn SHA trong nguồn đã đọc. Test widget dùng hàm mở bản đồ giả lập. |
| E05 | [Version khai báo](lbrc014-20261109/version-main.txt); [releases](lbrc014-20261109/releases.json); [deployments](lbrc014-20261109/deployments.json) | Main khai `1.0.27+29`; API releases/deployments trả danh sách rỗng. | Chưa có chứng cứ phát hành ở GitHub; chưa đọc Store/TestFlight hoặc gói app do team giữ. |
| E06 | [Quan sát Telegram](TELEGRAM-GROUP-VERIFICATION-20261109T0922.json); [biên nhận server](TELEGRAM-IDENTITY-VERIFICATION-20261109T022314Z.json) | LibeAI đọc được hồ sơ đúng SHA; Libe – Xeca bị chặn. | Chỉ chứng minh đường đọc và phân quyền của bot. Hồ sơ bot là snapshot, không phải bằng chứng UAT App Saleman. |

Chi tiết và giới hạn từng nguồn: [báo cáo đối soát](LBRC014-ACCEPTANCE-GAP-20261109.md). Danh sách hash của bằng chứng GitHub/Sheets: [MANIFEST](lbrc014-20261109/MANIFEST.json). Các tệp bằng chứng gốc được giữ nguyên.

## 4. Phần Quân cần bổ sung

Các ô dưới đây ghi yêu cầu bổ sung hồ sơ, chưa ghi nhận Quân đã cam kết thời hạn hoặc đã hoàn tất.

| Mã | Quân bổ sung | Thế nào là đủ | Liên kết / ngày dự kiến |
|---|---|---|---|
| Q1 | **Bản đã bàn giao và đã cài để nghiệm thu** | Full SHA build; version/build number của Android/iOS; gói cài hoặc mã build Store/TestFlight; nơi và ngày phát hành. Kèm ảnh thông tin phiên bản trên thiết bị đã dùng để nghiệm thu. Nối được bản này tới commit chức năng E02. Với gói cài trực tiếp, ghi thêm SHA-256 của gói. | Chờ Quân điền. |
| Q2 | **Kết quả kiểm thử và build** | Log chạy các test liên quan, phân tích/build theo quy trình team; ghi đúng SHA, công cụ/môi trường, ngày và kết quả. Log chạy tại máy hoặc CI đều dùng được nếu truy được nguồn. Ca lỗi/bỏ qua phải nêu rõ. | Chờ Quân điền. |
| Q3 | **Bằng chứng review đặc tả và mã** | Dẫn xác nhận của người có vai trò Arch/Tech Lead: spec/commit được review, ngày thực tế, kết luận và ngoại lệ. Quân tập hợp hồ sơ; người review xác nhận phần của mình. | Chờ Quân cung cấp nguồn review. |
| Q4 | **Bộ bằng chứng UAT kỹ thuật** | Điền ma trận ở mục 6: bản cài, thiết bị/OS, ca thử, kết quả, người thử, ảnh/video/log. Dùng dữ liệu thử hoặc che thông tin khách hàng không cần thiết. | Chờ Quân điền/phối hợp người kiểm thử. |

Nếu kết quả đã có từ ngày 07/11, dẫn lại đúng nguồn gốc. Nếu chạy bổ sung sau ngày lập biên bản, ghi ngày thực tế của lần chạy; giữ riêng kết quả cũ và kết quả bổ sung.

## 5. Phần Phương cần bổ sung

| Mã | Phương xác nhận | Nội dung cần ghi | Liên kết / ngày dự kiến |
|---|---|---|---|
| P1 | **Lời nghiệm thu ngày 07/11 áp dụng cho bản nào** | Đối chiếu với Q1; ghi bản cài/full SHA hoặc thông tin đủ truy ra bản cài, thiết bị đã dùng, phạm vi tính năng đã xem và nguồn xác nhận gốc. Nếu chưa xác định được bản cũ, ghi rõ để chốt phạm vi kiểm bổ sung. | Chờ Phương điền. |
| P2 | **Kết quả sử dụng thực tế và phạm vi đại diện nghiệm thu** | Ai thử/ai sử dụng; các màn và tiêu chí đã đạt; bằng chứng tương ứng; vai trò của người xác nhận đối với dự án. Trường hợp Phương chỉ điều phối, nêu người được giao nghiệm thu và nguồn giao quyền. | Chờ Phương điền. |
| P3 | **Kết luận sau khi đối chiếu hồ sơ** | Xác nhận mục 7, ghi ngoại lệ còn mở, mức ảnh hưởng, người xử lý và hạn được thống nhất. Các tiêu chí chưa có bằng chứng giữ trạng thái chờ xác nhận. | Chờ Phương xác nhận. |

Phần P1–P3 không suy ra quyền nghiệm thu từ riêng cột “Phối hợp”; mục đích là ghi nhận đúng người và phạm vi xác nhận thực tế.

## 6. Phiếu UAT để đính kèm kết quả

**Bản cài/version/build:** Chưa điền · **Full SHA build:** Chưa điền  
**Người thử:** Chưa điền · **Thiết bị/OS:** Chưa điền · **Ngày thử thực tế:** Chưa điền  
**Người xác nhận nghiệp vụ:** Chưa điền · **Nguồn bằng chứng:** Chưa điền

Trong các ô kết quả ghi `Đạt / Lỗi / Chưa kiểm / Không áp dụng có lý do`, cùng mã bằng chứng. Hiện mọi ô đều đang chờ bằng chứng; không mặc định đạt. Ma trận tổng hợp từ spec nội bộ, mục 2–8: `lbrc014-20261109/spec-main.txt:11`.

| Ca | Tiêu chí quan sát | Android + Google Maps | Android dùng trình duyệt | iOS |
|---|---|---|---|---|
| U1 | Tab Hôm nay: nút Chỉ đường hiện và mở đúng đích của điểm bán. | Chờ bổ sung | Chờ bổ sung | Chờ bổ sung |
| U2 | Danh sách Khách hàng: nút hiện và mở đúng đích; vẫn dùng được khi có tọa độ local nhưng địa chỉ màn trống. | Chờ bổ sung | Chờ bổ sung | Chờ bổ sung |
| U3 | Chi tiết KH: nút ở vị trí theo spec, mở đúng đích. | Chờ bổ sung | Chờ bổ sung | Chờ bổ sung |
| U4 | Ưu tiên tọa độ; thiếu tọa độ/0,0 thì dùng địa chỉ màn, rồi địa chỉ local. Kiểm cả đích hiển thị thực tế khi tìm bằng chữ. | Chờ bổ sung | Chờ bổ sung | Chờ bổ sung |
| U5 | Thiếu cả tọa độ và địa chỉ: giữ nguyên màn app, hiện thông báo thiếu thông tin. | Chờ bổ sung | Chờ bổ sung | Chờ bổ sung |
| U6 | Điểm chưa đồng bộ hoặc đọc local lỗi: dùng dữ liệu màn nếu có; xử lý thiếu dữ liệu theo spec. | Chờ bổ sung | Chờ bổ sung | Chờ bổ sung |
| U7 | Lỗi mở app/trình duyệt bản đồ: hiển thị thông báo lỗi, app tiếp tục hoạt động. | Chờ bổ sung | Chờ bổ sung | Chờ bổ sung |

Cấu hình Android dùng trình duyệt tương ứng ca thiết bị chưa cài Google Maps trong spec nội bộ: `lbrc014-20261109/spec-main.txt:82`. Các ca đã có bằng chứng phù hợp có thể dẫn lại. Người review và người nghiệm thu thống nhất ca cần bổ sung; ghi lý do cho ca không áp dụng. Việc đọc dữ liệu local và việc ứng dụng bản đồ tìm tuyến khi offline phải được ghi nhận riêng.

## 7. Phần xác nhận — để người có trách nhiệm hoàn tất

### 7.1. Quân xác nhận gói bàn giao

- Bản cài, full SHA build và liên kết Q1: **Chưa điền**.
- Test/build Q2, nguồn review Q3, UAT Q4: **Chưa điền**.
- Vấn đề còn mở và ảnh hưởng tới LBRC014: **Chưa điền**.
- Người cung cấp / ngày xác nhận thực tế: **Chưa xác nhận**.

### 7.2. Người review kỹ thuật xác nhận

- Họ tên / vai trò / phạm vi review: **Chưa điền**.
- Spec và commit đã review / nguồn kết quả: **Chưa điền**.
- Kết luận, ngoại lệ và ngày xác nhận thực tế: **Chưa xác nhận**.

### 7.3. Phương hoặc người được giao nghiệm thu xác nhận

- Họ tên / vai trò / phạm vi đại diện nghiệm thu: **Chưa điền**.
- Bản cài và bộ tiêu chí được nghiệm thu: **Chưa điền**.
- Liên kết kết quả UAT và bằng chứng: **Chưa điền**.
- Kết luận lựa chọn: **Chưa xác nhận** — Đạt / Đạt có điều kiện / Chưa đạt / Chưa đủ bằng chứng.
- Ngoại lệ, người xử lý, hạn được thống nhất: **Chưa điền**.
- Ngày nghiệm thu gốc / ngày bổ sung hồ sơ thực tế: **Chưa điền**.

Việc hoàn thiện hồ sơ cần nối được **tiêu chí → mã/build → bản cài → kết quả thử → người xác nhận**. Quyết định nghiệm thu thuộc người có trách nhiệm; trợ lý chỉ đối soát mức đầy đủ của bằng chứng. Lời báo nghiệm thu ngày 07/11 được giữ nguyên bên cạnh xác nhận bổ sung.

## 8. Bảo toàn nguồn và cách sử dụng hồ sơ

Biên bản được lập từ bộ bằng chứng đã đối soát sáng 09/11 và lưu riêng trong tài liệu LibeTech AI OS. Bảng việc, ghi chú của team, code GitHub, ticket và dữ liệu/snapshot của bot được giữ nguyên trong công việc lập biên bản này. Chưa gửi hồ sơ cho Quân hoặc Phương.

Bổ sung tài liệu bằng liên kết hoặc phụ lục có ngày/người cung cấp; giữ nguyên bằng chứng gốc. Nếu bản được nghiệm thu khác mốc mã đã ghi ở mục 2, đối chiếu phần thay đổi có ảnh hưởng đến LBRC014 rồi ghi kết quả; không tự thay mốc nghiệm thu bằng main mới nhất.
